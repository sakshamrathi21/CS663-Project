/*
 *  This test file exists to check for any compile-time problems
 *  when linking an application with both jbig.c and jbig85.c simultanenously.
 *
 *  Markus Kuhn -- http://www.cl.cam.ac.uk/~mgk25/
 */

#include "jbig.h"
#include "jbig85.h"

int main()
{
  return 0;
}
